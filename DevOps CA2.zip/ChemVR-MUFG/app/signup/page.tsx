import SignUp from '@/components/auth/signup';

export default function SignUpPage() {
  return <SignUp />;
}